#include "Link.h"
#include "Robot.h"
#include "task/Task.h"
#include <Arduino.h>


void Link::wait_start() const {
    for (;;) {
        serial_base->write('s');

        if (serial_base->available() || serial_debug->available()) {
            int16_t c = serial_base->read();
            int16_t d = serial_debug->read();
            if (c == 's' || d == 's') { return; }
        }
        delay(100);
    }
}

void Link::update() const {
    if (serial_base->available()) {
        char cmd = static_cast<char>(serial_base->read());
        Serial.print(cmd);
        Serial.println("  <- UART");
        process_command(cmd);
    }
}

void Link::update_debug() const {
    if (serial_debug->available()) {
        char cmd = static_cast<char>(serial_debug->read());
        Serial.println("  <- GET");
        process_command(cmd);
    }
}

void Link::process_command(char cmd) {
    auto& robot = Robot::instance();

    if (cmd == 'u' || cmd == 'l' || cmd == 'r' ||
        cmd == 'v' || cmd == 'b' || cmd == 'n' || cmd == 'm' ||
        cmd == 'c' || cmd == 'x' || cmd == 'e') {
        robot.reset();
        }

    if (cmd == 'u' || cmd == 'l' || cmd == 'r') {
        robot.tasks_move.push( TaskSent() );
    }

    if (cmd == 'u') {
        robot.tasks_move.push(TaskBlue());
        robot.tasks_move.push(TaskDelay(300));
        robot.tasks_move.push(TaskTouch(Quad_MM(50)));
        robot.tasks_move.push(TaskMove(
            SpeedProfile(30, 100, Quad_MM(300), Quad_MM(200), Quad_MM(50)),
            PID(0.15, 0, 0.04, -200, 200),
            PID(1.1, 0, 0.1, -30, 30)
        ));
    }

    switch (cmd) {
        case 'u': break;
        // Кейс 'd' полностью удалён
        case 'r': {
            robot.tasks_move.push(TaskRotate(SpeedProfile(30, 60, 85, 30, 30)));
            break;
        }
        case 'l': {
            auto rot = TaskRotate(SpeedProfile(30, 60, 85, 30, 30));
            rot.set_direction(-1);
            robot.tasks_move.push(rot);
            break;
        }
        /*case 'c': {
            if (millis() - robot.hardcode_delay < 1000) {
                LOG_INFO("HD");
                break;
            }
            robot.hardcode_delay = millis();

            float d = robot.dist_right.get();
            if (d < 200 && d != 0) {
                robot.tasks_victim.push(TaskLed2());
            } else {
                LOG_INFO("Not.", d);
            }
            break;
        }
        case 'x': {
            if (millis() - robot.hardcode_delay < 1000) {
                LOG_INFO("HD");
                break;
            }
            robot.hardcode_delay = millis();

            float d = robot.dist_left.get();
            if (d < 200 && d != 0) {
                robot.tasks_victim.push(TaskLed2());
            } else {
                LOG_INFO("Not.", d);
            }
            break;
        }*/
        case 'z': {
            robot.color.log();
            break;
        }
        case 'e': {
            robot.tasks_victim.push(TaskExit());
            break;
        }
        case 'g': {
            LOG_INFO("UPS: ", robot.delta_fast.get_ups());
            break;
        }
        default:
            break;
    }
}

void Link::send_sensors(const bool distance[4], uint8_t color) const {
    char packet[6];

    packet[0] = static_cast<char>('0' + (distance[0] ? 1 : 0));
    packet[1] = static_cast<char>('0' + (distance[1] ? 1 : 0));
    packet[2] = static_cast<char>('0' + (distance[2] ? 1 : 0));
    packet[3] = static_cast<char>('0' + (distance[3] ? 1 : 0));
    packet[4] = '0';
    packet[5] = '\0';

    serial_base->write((uint8_t*)packet, 5);

    serial_debug->print("[SENSORS SENT]: ");
    serial_debug->println(packet);
}

void Link::log_debug(const char* message) const {
    serial_debug->println(message);
}