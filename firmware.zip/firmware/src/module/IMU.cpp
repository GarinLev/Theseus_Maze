#include "IMU.h"
#include "Log.h"

bool IMU::init() {
    pid.reset();

    if (!mpu.testConnection()) {
        LOG_ERROR("MPU6050 connection failed!");
        return false;
    }

    mpu.initialize();

    uint8_t dev_status = mpu.dmpInitialize();

    if (dev_status == 0) {
        mpu.setXAccelOffset(-2224);
        mpu.setYAccelOffset(-3280);
        mpu.setZAccelOffset(1132);
        mpu.setXGyroOffset(-1854);
        mpu.setYGyroOffset(-69);
        mpu.setZGyroOffset(-17);

        mpu.setDMPEnabled(true);
        mpu.resetFIFO();

        return true;
    }

    if (dev_status != 0)
    {
        LOG_ERROR("Initialization failed. Code: ", dev_status);
        return false;
    }

    delay(700);

    return false;
}

void IMU::update() {
    if (mpu.dmpGetCurrentFIFOPacket(fifo_buffer)) {
        error_counter = 0;

        Quaternion q;
        VectorFloat gravity;

        mpu.dmpGetQuaternion(&q, fifo_buffer);
        mpu.dmpGetGravity(&gravity, &q);

        float data_ypr[3];
        mpu.dmpGetYawPitchRoll(data_ypr, &q, &gravity);

        ypr[0] = data_ypr[0] * 180.0f / M_PI;
        ypr[1] = data_ypr[1] * 180.0f / M_PI;
        ypr[2] = data_ypr[2] * 180.0f / M_PI;
    } else {
        error_counter++;

        if (error_counter > 5) {
            LOG_ERROR("IMU Frozen! Re-initializing I2C and DMP...");

            Wire.end();
            delay(5);
            Wire.begin();
            Wire.setWireTimeout(20000, true);

            if (init()) {
                LOG_INFO("IMU Hot-Reset Successful!");
            } else {
                LOG_ERROR("IMU Hot-Reset Failed!");
            }

            error_counter = 0;
        }
    }
}