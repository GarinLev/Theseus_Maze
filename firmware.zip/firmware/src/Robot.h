#ifndef FIRMWARE_ROBOT_H
#define FIRMWARE_ROBOT_H

#include <Ticker.h>
#include <microLED.h>
#include <uButton.h>

#include "Servo.h"
#include "link/Link.h"
#include "module/Dist.h"
#include "module/IMU.h"
#include "module/Quad.h"
#include "module/Wheel.h"
#include "task/Stack.h"
#include "task/Task.h"
#include "module/Color.h"
#include "delta/Delta.h"

constexpr size_t compile_max(size_t a, size_t b) {
    return a > b ? a : b;
}

constexpr size_t static_max(size_t a) {
    return a;
}

template <typename... Args>
constexpr size_t static_max(size_t a, Args... args) {
    return compile_max(a, static_max(args...));
}

constexpr size_t MAX_MOVE_SIZE = static_max(
    sizeof(TaskMove),
    sizeof(TaskRotate),
    sizeof(TaskTouch),
    sizeof(TaskDelay),
    sizeof(TaskSent),
    sizeof(TaskBlue),
    sizeof(TaskBlack),
    sizeof(TaskHit)
);

constexpr size_t MAX_VICTIM_SIZE = static_max(
    sizeof(TaskPush),
    sizeof(TaskLed)
);


class Robot {
public:
    Robot(const Robot&) = delete;
    Robot& operator=(const Robot&) = delete;

    static Robot& instance();

    void loop_slow();
    void loop_fast();

    Ticker timer_slow, timer_fast;
    Link link;
    Wheel w_fr, w_fl, w_br, w_bl;
    IMU imu;
    Quad quad;
    Dist dist_left, dist_right, dist_up, dist_down;
    Dist dist_pop_l, dist_pop_r;
    Color color;
    Servo servo;
    uButton button;
    microLED<11, 43, MLED_NO_CLOCK, LED_WS2818, ORDER_GRB, CLI_HIGH> led;
    Delta delta_fast;

    float rpm{}, steer{};

    uint8_t touch_pin_r, touch_pin_l;

    StaticStack<Task, 11, MAX_MOVE_SIZE> tasks_move;
    StaticStack<Task, 10, MAX_VICTIM_SIZE> tasks_victim;

    void update_tasks() const;
    boolean is_pause = false;
    void update_pause();

    void reset();

    bool is_last_black = false;
    uint32_t last_fast_millis = 0;
    uint32_t hardcode_delay = 0;

private:
    static void tramp_slow();
    static void tramp_fast();
    Robot();
};

#endif
