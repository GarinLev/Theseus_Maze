#include <Arduino.h>
#include "Robot.h"
#include "Task.h"

void TaskTouch::on_init() {
    step_timer = 0;
    step = Step::INIT;
}

void TaskTouch::on_execute(uint32_t dt) {
    auto& robot = Robot::instance();
    float dist = robot.dist_up.get();

    switch (step) {
        case Step::INIT:
            robot.rpm = 0;
            robot.steer = 0;
            if (elapsed_ms - step_timer >= 150) {

                if (dist > 200.0f || dist == 0.0f) {
                    done();
                } else {
                    step_timer = elapsed_ms;
                    step = Step::SEARCH;
                }
            }
            break;

        case Step::SEARCH:
            robot.rpm = 25;
            robot.steer = 0;

            if (elapsed_ms - step_timer >= 5000) {
                robot.rpm = 0;
                done();
                break;
            }

            if (digitalRead(robot.touch_pin_r) == LOW && digitalRead(robot.touch_pin_l) == LOW) {
                step_timer = elapsed_ms;
                step = Step::ALIGN;
            }
            break;

        case Step::ALIGN:
            robot.rpm = 20;
            robot.steer = 0;
            if (elapsed_ms - step_timer >= 300) {
                start_encoder = robot.quad.encoder();
                step = Step::BACK;
            }
            break;

        case Step::BACK:
            robot.rpm = -30;
            robot.steer = 0;

            float progress = fabsf(robot.quad.encoder() - start_encoder);

            if (progress >= back_ticks) {
                robot.rpm = 0;
                done();
            }
            break;
    }
}