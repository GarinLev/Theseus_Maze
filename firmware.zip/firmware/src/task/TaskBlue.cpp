#include "Robot.h"
#include "Task.h"

void TaskBlue::on_init() {
    auto& robot = Robot::instance();

    if (robot.color.get_current_color() == COLOR_BLACK || robot.color.get_current_color() == COLOR_RED) {

        if (robot.color.get_current_color() == COLOR_BLACK) {
            robot.tasks_victim.push(TaskLed());
        } else if (robot.color.get_current_color() == COLOR_RED) {
            robot.tasks_victim.push(TaskLed2());
        }
    }

    done();
}
void TaskBlue::on_execute(uint32_t dt) {
    if (!active) {
        done();
        return;
    }

    if (elapsed_ms > 5000) {
        done();
    }
}
