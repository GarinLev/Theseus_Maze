// 1. Сначала СУРОВО подключаем все контроллеры, чтобы типы стали полными
#include "../controller/controller_wheel.h"
#include "../controller/controller_wall.h"
#include "../controller/manager_wall.h"
#include "../controller/manager_wheel.h"
#include "../controller/controller_rotate.h"
#include "../controller/controller_servo.h"

// 2. И только ПОТОМ робота
#include "robot.h"

namespace robot {
    void handleWait() {
        wheelManager.stop();
    }

    void handleMove() {
        node_angel_run(rotateController.angel);
        if (!wheelManager.wall_disable) {
            wallRight.update();
            wallLeft.update();
        }
        else {
            wheelManager.fr->speed_offset = 0;
            wheelManager.fl->speed_offset = 0;
            wheelManager.bl->speed_offset = 0;
            wheelManager.br->speed_offset = 0;
        }
        wallManager.update();
    }

    void handleRotate() {
        rotateController.update();
    }

    void handleVictim() {
        servoController.update();
    }
}
