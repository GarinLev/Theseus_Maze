#include "robot.h"
#include <Arduino.h>
#include <Wire.h>

// Подключаем реализации структур
#include "../controller/controller_wheel.h"
#include "../controller/controller_wall.h"
#include "../controller/manager_wall.h"
#include "../controller/manager_wheel.h"
#include "../controller/controller_debug.h"
#include "../controller/controller_rotate.h"
#include "../controller/controller_servo.h"

namespace robot {
    struct pt thread;
    StateRobot state = StateRobot_WAIT;

    StateFunc stateTable[] = {
        &robot::handleWait,
        &robot::handleMove,
        &robot::handleRotate,
        &robot::handleVictim
    };

    TaskRobot task = TaskRobot_TEST;

    // Выделяем память под объекты
    WallManager wallManager;
    WallController wallRight;
    WallController wallLeft;

    WheelManager wheelManager;
    WheelController wheelA1;
    WheelController wheelA2;
    WheelController wheelB1;
    WheelController wheelB2;

    DebugController debug;
    RotateController rotateController;
    ServoController servoController;

    static void initWheel() {
        wheelA1.init(500.0f, 140.0f);
        wheelA1.setPins(4, 5, false, 2, 22, robot::isr_encoder_A1);

        wheelA2.init(500.0f, 140.0f);
        wheelA2.setPins(8, 9, false, 18, 24, robot::isr_encoder_A2);

        wheelB1.init(500.0f, 140.0f);
        wheelB1.setPins(6, 7, true, 3, 23, robot::isr_encoder_B1);

        wheelB2.init(500.0f, 140.0f);
        wheelB2.setPins(10, 12, true, 19, 25, robot::isr_encoder_B2);

        wheelManager.fr = &wheelA1;
        wheelManager.fl = &wheelA2;
        wheelManager.br = &wheelB1;
        wheelManager.bl = &wheelB2;

        wheelManager.init();
        wheelManager.setPitchSource(&rotateController.angel.ypr[1]);
        wheelManager.setDistSource(&wallRight.nodeExtra);
    }

    static void initWall() {
        wallRight.setPins(&Wire, 0x30, 0x31, 0x32, 37, 36, 32);
        wallLeft.setPins(&Wire, 0x33, 0x34, 0x35, 33, 34, 35);

        wallRight.reset();
        wallLeft.reset();
        delay(50);

        wallRight.setAddr();
        wallLeft.setAddr();

        wallRight.init();
        wallLeft.init();

        wallManager.wheelA1 = &wheelA1;
        wallManager.wheelA2 = &wheelA2;
        wallManager.wheelB1 = &wheelB1;
        wallManager.wheelB2 = &wheelB2;
        wallManager.sens_left = &wallLeft;
        wallManager.sens_right = &wallRight;
        wallManager.init();
    }

    static void initRotate() {
        rotateController.init();
        rotateController.wheelA1 = &wheelA1;
        rotateController.wheelA2 = &wheelA2;
        rotateController.wheelB1 = &wheelB1;
        rotateController.wheelB2 = &wheelB2;
    }

    static void initServo() {
        servoController.pin = 44;
        servoController.init();
    }

    void init() {
        Serial.begin(115200);
        Wire.begin();
        Wire.setClock(400000);

        initWheel();
        initWall();
        initRotate();
        initServo();

        PT_INIT(&thread);
    }
}
