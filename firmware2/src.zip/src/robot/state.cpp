#include "robot.h"

namespace robot {
    void loop() {
        debug.frame();
        debug.update();
        debug.ups_update();

        state_update();
        (stateTable[state])();

        wheelManager.update();
    }

    int state_update() {
        PT_BEGIN(&thread);
        for (;;) {
            if (task == TaskRobot_STEP_UP) {
                state = StateRobot_MOVE;

                wheelManager.moveDistance(300.0f, 100.0f, &rotateController.angel.ypr[0]);
                PT_WAIT_WHILE(&thread, wheelManager.is_moving);

                task = TaskRobot_WAIT;
            }

            else if (task >= TaskRobot_VICTIM_LEFT && task <= TaskRobot_VICTIM_LEFT_X2) {
                state = StateRobot_VICTIM;

                bool isLeft = (task == TaskRobot_VICTIM_LEFT || task == TaskRobot_VICTIM_LEFT_X2);
                bool isX2 = (task == TaskRobot_VICTIM_LEFT_X2 || task == TaskRobot_VICTIM_RIGHT_X2);

                servoController.set(isLeft ? ServoController_Left : ServoController_Right);
                PT_WAIT_WHILE(&thread, servoController.is_active);

                servoController.set(isLeft ? ServoController_CloseLeft : ServoController_CloseRight);
                PT_WAIT_WHILE(&thread, servoController.is_active);

                if (isX2) {
                    servoController.set(isLeft ? ServoController_Left : ServoController_Right);
                    PT_WAIT_WHILE(&thread, servoController.is_active);

                    servoController.set(isLeft ? ServoController_CloseLeft : ServoController_CloseRight);
                    PT_WAIT_WHILE(&thread, servoController.is_active);
                }

                task = TaskRobot_WAIT;
            }

            else if (task == TaskRobot_WAIT) {
                state = StateRobot_WAIT;
            }

            PT_YIELD(&thread);
        }
        PT_END(&thread);
    }
}
