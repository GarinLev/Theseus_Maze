#pragma once

// 1. Опережающие объявления ВСЕГДА в начале
namespace robot {
    struct WallManager;
    struct WallController;
    struct WheelManager;
    struct WheelController;
    struct DebugController;
    struct RotateController;
    struct ServoController;
}

// 2. ВАЖНО: сначала определяем перечисления, чтобы они были доступны всем
namespace robot {
    enum StateRobot {
        StateRobot_WAIT = 0,
        StateRobot_MOVE = 1,
        StateRobot_ROTATE = 2,
        StateRobot_VICTIM = 3
    };
    enum TaskRobot : int {
        TaskRobot_WAIT, TaskRobot_STEP_UP, TaskRobot_STEP_DOWN,
        TaskRobot_STEP_LEFT, TaskRobot_STEP_RIGHT, TaskRobot_VICTIM_LEFT,
        TaskRobot_VICTIM_RIGHT, TaskRobot_VICTIM_LEFT_X2, TaskRobot_VICTIM_RIGHT_X2,
        TaskRobot_TEST
    };
}

// 3. ТЕПЕРЬ инклюдим контроллеры
#include "../controller/controller_wheel.h"
#include "../controller/controller_wall.h"
#include "../controller/manager_wall.h"
#include "../controller/manager_wheel.h"
#include "../controller/controller_debug.h"
#include "../controller/controller_rotate.h"
#include "../controller/controller_servo.h"

// 4. И наконец объявляем extern-переменные
namespace robot {
    typedef void (*StateFunc)();

    extern TaskRobot task;
    extern StateRobot state;
    extern StateFunc stateTable[];

    extern WallManager wallManager;
    extern WallController wallRight;
    extern WallController wallLeft;

    extern WheelManager wheelManager;
    extern WheelController wheelA1;
    extern WheelController wheelA2;
    extern WheelController wheelB1;
    extern WheelController wheelB2;

    extern DebugController debug;
    extern RotateController rotateController;
    extern ServoController servoController;

    void init();
    void loop();
    void isr_encoder_A1();
    void isr_encoder_A2();
    void isr_encoder_B1();
    void isr_encoder_B2();
}
